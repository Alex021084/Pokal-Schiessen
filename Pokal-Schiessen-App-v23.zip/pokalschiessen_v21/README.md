# Pokal-Schiessen-App v21

Die neue PDF-Vorlage `Schießzettel Pokal App(1).pdf` wurde als feste Druckvorlage übernommen. Das Layout wird nicht neu aufgebaut.

Beim Erstellen des Schießzettels werden die in der App eingegebenen Angaben an den vorgesehenen Stellen auf die Vorlage gelegt:
- Verein
- Telefon
- Mannschaft
- Schießart Satz 1 / Satz 2
- erste Scheibennummer je Satz
- daraus automatisch die drei fortlaufenden Scheibennummern und die vierte Nummer beim Teiler

Nach Klick auf „Schießzettel erstellen“ wird die fertige Vorschau in einem eigenen Fenster/Overlay angezeigt. Dort gibt es den Drucken-Button. Beim Drucken werden beide Hälften auf genau eine DIN-A4-Seite gesetzt.
