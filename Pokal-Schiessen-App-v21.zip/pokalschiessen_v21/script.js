const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));

function showStart(selectId, wrapId, inputId) {
  const el = $(selectId);
  el.addEventListener('change', () => {
    const active = !!el.value;
    $(wrapId).classList.toggle('hidden', !active);
    if (active) $(inputId).focus();
  });
}

function sheet(data, setNo) {
  const {verein, telefon, mannschaft, art, start} = data;
  const nums = [start, start + 1, start + 2];
  const teilerNr = start + 3;
  return `
  <article class="sheet">
    <img class="sheet-bg" src="assets/template-clean.png" alt="">
    <div class="overlay">
      <div class="value verein">${esc(verein)}</div>
      <div class="value telefon">${esc(telefon)}</div>
      <div class="value mannschaft">${esc(mannschaft)}</div>
      <div class="value art">${esc(art)}</div>
      <div class="value sn sn1">${nums[0]}</div>
      <div class="value sn sn2">${nums[1]}</div>
      <div class="value sn sn3">${nums[2]}</div>
      <div class="value teiler-nr">${teilerNr}</div>
    </div>
  </article>`;
}

function make() {
  const verein = $('verein').value.trim();
  const telefon = $('telefon').value.trim();
  const mannschaft = $('mannschaft').value;
  const art1 = $('art1').value;
  const art2 = $('art2').value;
  const s1 = Number($('start1').value);
  const s2 = Number($('start2').value);

  if (!art1 || !art2 || !s1 || !s2) {
    alert('Bitte für beide Sätze die Schießart und die erste Scheibennummer eingeben.');
    return;
  }

  $('out').innerHTML =
    sheet({verein, telefon, mannschaft, art: art1, start: s1}, 1) +
    sheet({verein, telefon, mannschaft, art: art2, start: s2}, 2);

  $('previewModal').classList.remove('hidden');
  document.body.classList.add('preview-open');
}

function closePreview() {
  $('previewModal').classList.add('hidden');
  document.body.classList.remove('preview-open');
}

document.addEventListener('DOMContentLoaded', () => {
  showStart('art1', 'startWrap1', 'start1');
  showStart('art2', 'startWrap2', 'start2');
  $('make').addEventListener('click', make);
  $('closePreview').addEventListener('click', closePreview);
  $('previewModal').addEventListener('click', e => { if (e.target === $('previewModal')) closePreview(); });
  $('print').addEventListener('click', () => window.print());
});
